#ifndef NOKOGIRI_XML_XPATH_CONTEXT
#define NOKOGIRI_XML_XPATH_CONTEXT

#include <nokogiri.h>

void init_xml_xpath_context();

extern VALUE cNokogiriXmlXpathContext;
#endif
