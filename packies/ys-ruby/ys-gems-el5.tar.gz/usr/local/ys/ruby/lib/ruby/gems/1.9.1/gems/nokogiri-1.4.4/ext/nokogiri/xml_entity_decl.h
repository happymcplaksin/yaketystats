#ifndef NOKOGIRI_XML_ENTITY_DECL
#define NOKOGIRI_XML_ENTITY_DECL

#include <nokogiri.h>

void init_xml_entity_decl();

extern VALUE cNokogiriXmlEntityDecl;
#endif

