module Nokogiri
  module CSS
    class Tokenizer < GeneratedTokenizer
      alias :scan :scan_setup
    end
  end
end
