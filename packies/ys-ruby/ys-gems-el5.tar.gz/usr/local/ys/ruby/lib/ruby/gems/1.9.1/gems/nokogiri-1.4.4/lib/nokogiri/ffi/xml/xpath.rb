module Nokogiri
  module XML
    class XPath
      
      attr_accessor :cstruct # :nodoc:

    end
  end
end
