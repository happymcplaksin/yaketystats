#ifndef NOKOGIRI_HTML_ENTITY_LOOKUP
#define NOKOGIRI_HTML_ENTITY_LOOKUP

#include <nokogiri.h>

void init_html_entity_lookup();

#endif
