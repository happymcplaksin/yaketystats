#ifndef NOKOGIRI_XML_ENTITY_REFERENCE
#define NOKOGIRI_XML_ENTITY_REFERENCE

#include <nokogiri.h>

void init_xml_entity_reference();

extern VALUE cNokogiriXmlEntityReference;
#endif
