module TZInfo
  module Definitions
    module Universal
      include TimezoneDefinition
      
      linked_timezone 'Universal', 'Etc/UTC'
    end
  end
end
