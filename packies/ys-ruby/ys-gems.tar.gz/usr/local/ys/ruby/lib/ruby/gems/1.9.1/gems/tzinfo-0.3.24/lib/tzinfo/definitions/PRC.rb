module TZInfo
  module Definitions
    module PRC
      include TimezoneDefinition
      
      linked_timezone 'PRC', 'Asia/Shanghai'
    end
  end
end
